var config = {
    HOST_URL: 'https://tracker-221417.appspot.com/',
    APP_ID: 'amzn1.ask.skill.a05198f1-2a71-4691-bba0-1c125c1bc770',
    ED_URL: 'https://api.edamam.com/api/food-database/parser/',
}